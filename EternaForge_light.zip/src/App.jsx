import React, { useState } from 'react';

function App() {
  const [token, setToken] = useState({
    id: 1,
    uri: "ipfs://QmExampleInitialMetadata"
  });

  function simulateEvolve() {
    setToken({
      ...token,
      uri: "ipfs://QmExampleEvolvedMetadata"
    });
    alert("Simulated evolve: metadata URI updated (demo only).");
  }

  return (
    <div style={{ padding: 24, fontFamily: 'Arial, sans-serif' }}>
      <h1>EternaForge — Light Demo</h1>
      <p>Token ID: {token.id}</p>
      <p>Metadata URI: <code>{token.uri}</code></p>
      <button onClick={simulateEvolve}>Simulate Evolve</button>
      <p style={{ marginTop: 16, color: '#666' }}>
        Note: This is a front-end simulation. Real evolve events would be triggered by Somnia Data Streams.
      </p>
    </div>
  );
}

export default App;
