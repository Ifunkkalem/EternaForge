# EternaForge (Light Demo)

EternaForge — Dynamic NFT Game Items Powered by Somnia Data Streams (Light demo)

This light demo contains a minimal project structure intended for Somnia Builder application.
It includes a simple ERC-721 contract (illustrative), a tiny React entry file for demo UI,
and minimal config files. This package is *not* production-ready; it's a compact demo for submission.

## Structure
- contracts/EvolvingItem.sol  — example ERC-721 contract with an `evolve` hook
- src/App.jsx                — minimal React demo UI for previewing an NFT and simulating evolve
- package.json               — minimal metadata
- hardhat.config.js          — minimal Hardhat config (for reference)

## Notes
- Replace the dummy GitHub link in your application with your real repo after uploading.
- If you want the full deployable version later, I can prepare a complete Hardhat + React setup.
