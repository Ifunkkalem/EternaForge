require("@nomiclabs/hardhat-waffle");
/** Minimal Hardhat config for reference in light demo */
module.exports = {
  solidity: "0.8.19",
  networks: {
    hardhat: {}
  }
};
