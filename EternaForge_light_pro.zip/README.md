# 🧠 EternaForge — Dynamic NFT Game Items Powered by Somnia Data Streams

> “Every item tells a story — EternaForge lets it evolve.”

EternaForge introduces a new paradigm for **Web3 gaming assets**, where each **NFT item dynamically evolves** based on live data.  
By leveraging **Somnia’s Data Streams SDK**, NFTs can now react to gameplay progress, achievements, or any real-time metric, creating a bridge between blockchain and active game worlds.

---

## ⚙️ Core Concept

In traditional games, assets are static — once minted, they never change.  
EternaForge transforms this by enabling **NFTs that evolve**, upgrade, or mutate based on **real-time data** coming from Somnia’s Data Streams.

| Feature | Description |
|----------|-------------|
| 🧩 **Dynamic Metadata** | NFT attributes and visuals evolve automatically. |
| 🔗 **Somnia SDK Integration** | Real-time data flow directly to smart contracts. |
| ⚡ **Live Evolution Events** | Each item’s metadata updates on-chain as players progress. |
| 🌐 **Fully On-chain** | Every evolution, ownership change, and metadata update is recorded transparently. |

---

## 🧬 Example Use Case

Imagine a sword NFT in a blockchain RPG game:
- Player defeats monsters → XP increases in Somnia Data Stream  
- Smart contract receives signal → sword metadata evolves  
- The NFT image updates to a glowing “Epic Blade” version  
- Player can show or trade it in real time  

That’s the **EternaForge experience** — living NFTs that grow with their holders.

---

## 🧰 Tech Stack

- Solidity + Hardhat (contract layer)
- Somnia Data Streams SDK
- React + Wagmi + Ethers.js (frontend)
- IPFS / NFT.Storage (metadata hosting)
- OpenZeppelin ERC721 base

---

## 🧾 Smart Contract Overview

A minimal ERC721 token with an **`evolve()`** function that updates the NFT’s metadata URI — simulating real-time updates from Somnia Data Streams.  
For this demo, metadata changes are triggered manually, but in full integration, these would be **event-driven**.

---

## 👥 Team — EternaForge Labs

- **ifunkkalem** — Founder & Smart Contract Developer  
- **Alyra M.** — Game Designer & Visual Artist  
- **R. Den** — Blockchain Engineer  

---

## 🚀 Vision

To build a framework that empowers any game developer to connect live gameplay data to NFT evolution,  
turning static collectibles into **living digital entities**.

---

## 📂 Repository Structure

```
/contracts
  └── EvolvingItem.sol      # Minimal evolving NFT contract
/src
  └── App.jsx               # React simulation of evolve event
/package.json
/hardhat.config.js
/README.md
```

---

## 🪙 Future Plans

- Integrate full **Somnia Data Streams SDK**  
- Enable automatic evolution based on off-chain data  
- Build **EternaForge Dashboard** for minting & managing live NFTs  
- Deploy contracts to Somnia testnet and showcase live item transformations  

---

## 💬 Contact

Twitter: [@ifunkkalem91](https://x.com/ifunkkalem91)  
Discord: `ifunkkalem`  
Email: `contact@eternaforge.xyz` (optional placeholder)
